from flask import render_template, request, jsonify
from app import app, allowed_file
import base64
import io

@app.route('/')
def index():
    """Main application page with audio visualizer"""
    return render_template('index.html')

@app.route('/upload-background', methods=['POST'])
def upload_background():
    """Handle background image upload"""
    try:
        if 'background' not in request.files:
            return jsonify({'success': False, 'error': 'No file provided'})
        
        file = request.files['background']
        if file.filename == '' or file.filename is None:
            return jsonify({'success': False, 'error': 'No file selected'})
        
        if file and allowed_file(file.filename):
            # Read file data and convert to base64
            file_data = file.read()
            file_base64 = base64.b64encode(file_data).decode('utf-8')
            file_extension = file.filename.rsplit('.', 1)[1].lower()
            
            # Create data URL
            data_url = f"data:image/{file_extension};base64,{file_base64}"
            
            return jsonify({
                'success': True, 
                'image_url': data_url,
                'message': 'Background image uploaded successfully'
            })
        else:
            return jsonify({'success': False, 'error': 'Invalid file type'})
    
    except Exception as e:
        app.logger.error(f"Error uploading background: {str(e)}")
        return jsonify({'success': False, 'error': 'Upload failed'})

@app.route('/upload-audio', methods=['POST'])
def upload_audio():
    """Handle audio file upload"""
    try:
        if 'audio' not in request.files:
            return jsonify({'success': False, 'error': 'No audio file provided'})
        
        file = request.files['audio']
        if file.filename == '' or file.filename is None:
            return jsonify({'success': False, 'error': 'No file selected'})
        
        # Check if it's an audio file
        audio_extensions = {'mp3', 'wav', 'ogg', 'm4a', 'flac', 'aac'}
        if file and '.' in file.filename and file.filename.rsplit('.', 1)[1].lower() in audio_extensions:
            # Read file data and convert to base64
            file_data = file.read()
            file_base64 = base64.b64encode(file_data).decode('utf-8')
            file_extension = file.filename.rsplit('.', 1)[1].lower()
            
            # Create data URL for audio
            mime_type = {
                'mp3': 'audio/mpeg',
                'wav': 'audio/wav',
                'ogg': 'audio/ogg',
                'm4a': 'audio/mp4',
                'flac': 'audio/flac',
                'aac': 'audio/aac'
            }.get(file_extension, 'audio/mpeg')
            
            data_url = f"data:{mime_type};base64,{file_base64}"
            
            return jsonify({
                'success': True, 
                'audio_url': data_url,
                'filename': file.filename,
                'message': 'Audio file uploaded successfully'
            })
        else:
            return jsonify({'success': False, 'error': 'Invalid audio file type. Supported formats: MP3, WAV, OGG, M4A, FLAC, AAC'})
    
    except Exception as e:
        app.logger.error(f"Error uploading audio: {str(e)}")
        return jsonify({'success': False, 'error': 'Audio upload failed'})

@app.route('/api/audio-settings', methods=['POST'])
def save_audio_settings():
    """Save audio visualization settings"""
    try:
        data = request.get_json()
        # In a real application, you might save these to a database
        # For now, just return success
        return jsonify({'success': True, 'message': 'Settings saved'})
    except Exception as e:
        app.logger.error(f"Error saving settings: {str(e)}")
        return jsonify({'success': False, 'error': 'Failed to save settings'})
