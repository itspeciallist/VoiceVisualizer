# Overview

This is a real-time audio visualizer web application that analyzes microphone input to detect gender characteristics in voice and provides visual feedback. The application uses Flask as the backend framework and vanilla JavaScript for frontend audio processing. It features real-time frequency analysis, gender detection based on fundamental frequency ranges, customizable visualizations, and theme switching capabilities.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Single Page Application**: Uses vanilla JavaScript with modular class-based architecture
- **Canvas-based Visualization**: HTML5 Canvas for real-time audio rendering with customizable visualization types (waveform, frequency bars)
- **Web Audio API Integration**: Direct browser microphone access using getUserMedia() and AudioContext for real-time audio analysis
- **Component-based Design**: Separate classes for AudioVisualizer, GenderDetector, ThemeManager, FullscreenHandler, and BackgroundManager
- **Bootstrap UI Framework**: Responsive design with Bootstrap 5 for consistent styling and mobile compatibility

## Backend Architecture
- **Flask Web Framework**: Lightweight Python web server handling HTTP requests and file uploads
- **RESTful API Design**: JSON-based endpoints for settings management and file uploads
- **File Upload System**: Secure image upload handling with base64 encoding for background images
- **Session Management**: Flask sessions with configurable secret key for user state
- **Template Rendering**: Jinja2 templating for HTML generation

## Audio Processing Pipeline
- **Real-time Analysis**: Continuous audio capture and frequency domain analysis using FFT
- **Gender Detection Algorithm**: Fundamental frequency analysis comparing against typical male (85-180 Hz) and female (165-265 Hz) vocal ranges
- **Confidence Scoring**: Statistical analysis with configurable confidence thresholds and historical data averaging
- **Visual Feedback**: Dynamic color coding and real-time visualization updates based on detected gender

## State Management
- **Client-side Settings**: Local storage for user preferences and theme selection
- **Session-based Data**: Server-side session handling for temporary user data
- **Real-time Updates**: Event-driven architecture for live audio visualization updates

## Security Considerations
- **File Upload Validation**: Restricted file types and size limits for background image uploads
- **Input Sanitization**: Secure filename handling using Werkzeug utilities
- **CORS Protection**: Proxy fix middleware for proper header handling in production environments

# External Dependencies

## Frontend Libraries
- **Bootstrap 5**: CSS framework for responsive UI components and styling
- **Font Awesome 6**: Icon library for navigation and control elements
- **Web Audio API**: Browser-native audio processing capabilities
- **Canvas API**: HTML5 canvas for real-time graphics rendering

## Backend Dependencies
- **Flask**: Python web framework for HTTP request handling
- **Werkzeug**: WSGI utilities for secure file handling and proxy support
- **Base64 Encoding**: Built-in Python library for image data conversion

## Browser APIs
- **MediaDevices API**: Microphone access for audio input capture
- **Fullscreen API**: Browser fullscreen mode support
- **Local Storage API**: Client-side data persistence for user preferences

## Development Tools
- **Python Logging**: Built-in logging system for debugging and error tracking
- **Flask Debug Mode**: Development server with hot reloading capabilities