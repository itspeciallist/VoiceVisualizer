/**
 * Audio Visualizer - Main application class for audio file visualization
 */
class AudioVisualizer {
    constructor() {
        this.audioContext = null;
        this.analyzer = null;
        this.audioElement = null;
        this.audioSource = null;
        this.canvas = null;
        this.ctx = null;
        this.animationId = null;
        this.isPlaying = false;
        this.backgroundImage = null;
        this.currentAudioFile = null;
        
        // Audio analysis data
        this.frequencyData = null;
        this.timeData = null;
        this.bufferLength = 0;
        
        // Settings
        this.settings = {
            fftSize: 1024,
            smoothingTimeConstant: 0.8,
            sensitivity: 5,
            visualizationType: 'waveform',
            animationSpeed: 5,
            smoothAnimation: true,
            maleColor: '#007bff',
            femaleColor: '#dc3545',
            backgroundOpacity: 0.8
        };
        
        // Initialize components
        this.genderDetector = new window.GenderDetector();
        this.fullscreenHandler = new FullscreenHandler();
        this.backgroundManager = new BackgroundManager();
        
        this.init();
    }
    
    init() {
        this.setupCanvas();
        this.setupEventListeners();
        this.loadSettings();
        this.startVisualization();
        
        console.log('Audio Visualizer initialized');
    }
    
    setupCanvas() {
        this.canvas = document.getElementById('visualizationCanvas');
        if (!this.canvas) {
            console.error('Canvas element not found');
            return;
        }
        
        this.ctx = this.canvas.getContext('2d');
        this.resizeCanvas();
        
        // Handle canvas resize
        window.addEventListener('resize', () => this.resizeCanvas());
    }
    
    resizeCanvas() {
        if (!this.canvas || !this.canvas.parentElement) return;
        
        const container = this.canvas.parentElement;
        const rect = container.getBoundingClientRect();
        
        // Set canvas size to match container
        this.canvas.width = rect.width;
        this.canvas.height = Math.max(rect.height, 500);
        
        // Update canvas style
        this.canvas.style.width = rect.width + 'px';
        this.canvas.style.height = this.canvas.height + 'px';
    }
    
    setupEventListeners() {
        // Audio file upload
        const audioUpload = document.getElementById('audioUpload');
        if (audioUpload) {
            audioUpload.addEventListener('change', (e) => this.handleAudioUpload(e));
        }
        
        // Play/Pause toggle
        const playToggle = document.getElementById('playToggle');
        if (playToggle) {
            playToggle.addEventListener('click', () => this.togglePlayback());
        }
        
        // Visualization type
        const visualizationType = document.getElementById('visualizationType');
        if (visualizationType) {
            visualizationType.addEventListener('change', (e) => {
                this.settings.visualizationType = e.target.value;
                this.saveSettings();
            });
        }
        
        // Sensitivity
        const sensitivity = document.getElementById('sensitivity');
        if (sensitivity) {
            sensitivity.addEventListener('input', (e) => {
                this.settings.sensitivity = parseInt(e.target.value);
                this.saveSettings();
            });
        }
        
        // Settings modal
        this.setupSettingsModal();
        
        // Theme change listener
        window.addEventListener('themeChanged', () => {
            this.updateThemeColors();
        });
    }
    
    setupSettingsModal() {
        const saveSettingsBtn = document.getElementById('saveSettings');
        if (saveSettingsBtn) {
            saveSettingsBtn.addEventListener('click', () => this.saveModalSettings());
        }
        
        // Load current settings into modal
        const settingsModal = document.getElementById('settingsModal');
        if (settingsModal) {
            settingsModal.addEventListener('show.bs.modal', () => this.loadModalSettings());
        }
    }
    
    async handleAudioUpload(event) {
        const file = event.target.files[0];
        if (!file) return;
        
        try {
            console.log('Loading audio file:', file.name);
            
            // Create audio element
            if (this.audioElement) {
                this.audioElement.pause();
                this.audioElement = null;
            }
            
            // Create new audio element
            this.audioElement = new Audio();
            this.audioElement.preload = 'auto';
            this.audioElement.crossOrigin = 'anonymous';
            
            // Set up audio event listeners
            this.audioElement.addEventListener('loadeddata', () => {
                this.setupAudioAnalysis();
                this.enablePlayButton();
                this.showToast(`Audio file "${file.name}" loaded successfully`, 'success');
            });
            
            this.audioElement.addEventListener('error', (e) => {
                console.error('Audio loading error:', e);
                this.showToast('Error loading audio file', 'error');
            });
            
            this.audioElement.addEventListener('ended', () => {
                this.stopPlayback();
            });
            
            // Load the file
            const url = URL.createObjectURL(file);
            this.audioElement.src = url;
            this.currentAudioFile = file;
            
        } catch (error) {
            console.error('Error handling audio upload:', error);
            this.showToast('Failed to load audio file', 'error');
        }
    }
    
    setupAudioAnalysis() {
        try {
            // Create audio context if not exists
            if (!this.audioContext) {
                this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
            }
            
            // Resume audio context if suspended
            if (this.audioContext.state === 'suspended') {
                this.audioContext.resume();
            }
            
            // Create analyzer
            this.analyzer = this.audioContext.createAnalyser();
            this.analyzer.fftSize = this.settings.fftSize;
            this.analyzer.smoothingTimeConstant = this.settings.smoothingTimeConstant;
            
            // Create audio source
            if (this.audioSource) {
                this.audioSource.disconnect();
            }
            this.audioSource = this.audioContext.createMediaElementSource(this.audioElement);
            
            // Connect audio graph: source -> analyzer -> destination
            this.audioSource.connect(this.analyzer);
            this.analyzer.connect(this.audioContext.destination);
            
            // Setup data arrays
            this.bufferLength = this.analyzer.frequencyBinCount;
            this.frequencyData = new Uint8Array(this.bufferLength);
            this.timeData = new Uint8Array(this.bufferLength);
            
            console.log('Audio analysis setup complete');
            
        } catch (error) {
            console.error('Error setting up audio analysis:', error);
            this.showToast('Error setting up audio analysis', 'error');
        }
    }
    
    enablePlayButton() {
        const playToggle = document.getElementById('playToggle');
        if (playToggle) {
            playToggle.disabled = false;
        }
    }
    
    togglePlayback() {
        if (this.isPlaying) {
            this.pausePlayback();
        } else {
            this.startPlayback();
        }
    }
    
    async startPlayback() {
        if (!this.audioElement) {
            this.showToast('Please upload an audio file first', 'error');
            return;
        }
        
        try {
            // Resume audio context if needed
            if (this.audioContext && this.audioContext.state === 'suspended') {
                await this.audioContext.resume();
            }
            
            await this.audioElement.play();
            this.isPlaying = true;
            this.updatePlaybackUI();
            this.hideStatusOverlay();
            
            console.log('Audio playback started');
            
        } catch (error) {
            console.error('Error starting playback:', error);
            this.showToast('Error starting playback', 'error');
        }
    }
    
    pausePlayback() {
        if (this.audioElement) {
            this.audioElement.pause();
        }
        this.isPlaying = false;
        this.updatePlaybackUI();
        this.genderDetector.reset();
        
        console.log('Audio playback paused');
    }
    
    stopPlayback() {
        if (this.audioElement) {
            this.audioElement.pause();
            this.audioElement.currentTime = 0;
        }
        this.isPlaying = false;
        this.updatePlaybackUI();
        this.showStatusOverlay();
        this.genderDetector.reset();
        
        console.log('Audio playback stopped');
    }
    
    updatePlaybackUI() {
        const playToggle = document.getElementById('playToggle');
        if (!playToggle) return;
        
        if (this.isPlaying) {
            playToggle.innerHTML = '<i class="fas fa-pause me-2"></i>Pause Audio';
            playToggle.className = 'btn btn-warning w-100 mb-3 playing';
        } else {
            playToggle.innerHTML = '<i class="fas fa-play me-2"></i>Play Audio';
            playToggle.className = 'btn btn-success w-100 mb-3';
        }
    }
    
    showStatusOverlay() {
        const overlay = document.querySelector('.canvas-overlay');
        if (overlay) {
            overlay.classList.remove('hidden');
        }
    }
    
    hideStatusOverlay() {
        const overlay = document.querySelector('.canvas-overlay');
        if (overlay) {
            overlay.classList.add('hidden');
        }
    }
    
    startVisualization() {
        const animate = () => {
            this.animationId = requestAnimationFrame(animate);
            this.draw();
        };
        animate();
    }
    
    draw() {
        if (!this.canvas || !this.ctx) return;
        
        // Clear canvas
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Draw background if set
        this.backgroundManager.drawBackground(this.ctx, this.canvas.width, this.canvas.height);
        
        if (!this.isPlaying || !this.analyzer) {
            return;
        }
        
        // Get audio data
        this.analyzer.getByteFrequencyData(this.frequencyData);
        this.analyzer.getByteTimeDomainData(this.timeData);
        
        // Update audio level indicator
        this.updateAudioLevel();
        
        // Perform gender detection
        this.genderDetector.analyzeGender(
            this.frequencyData,
            this.audioContext.sampleRate,
            this.analyzer.fftSize
        );
        
        // Draw visualization based on type
        this.drawVisualization();
    }
    
    updateAudioLevel() {
        if (!this.timeData) return;
        
        // Calculate RMS level
        let sum = 0;
        for (let i = 0; i < this.timeData.length; i++) {
            const sample = (this.timeData[i] - 128) / 128;
            sum += sample * sample;
        }
        const rms = Math.sqrt(sum / this.timeData.length);
        const level = Math.min(rms * this.settings.sensitivity * 2, 1);
        
        // Update UI
        const audioLevel = document.getElementById('audioLevel');
        if (audioLevel) {
            audioLevel.style.width = (level * 100) + '%';
        }
    }
    
    drawVisualization() {
        const genderColor = this.genderDetector.getGenderColor();
        
        switch (this.settings.visualizationType) {
            case 'waveform':
                this.drawWaveform(genderColor);
                break;
            case 'frequency':
                this.drawFrequencyBars(genderColor);
                break;
            case 'circular':
                this.drawCircularVisualization(genderColor);
                break;
            case 'particles':
                this.drawParticles(genderColor);
                break;
            default:
                this.drawWaveform(genderColor);
        }
    }
    
    drawWaveform(color) {
        if (!this.timeData) return;
        
        this.ctx.lineWidth = 3;
        this.ctx.strokeStyle = color;
        this.ctx.beginPath();
        
        const sliceWidth = this.canvas.width / this.timeData.length;
        let x = 0;
        
        for (let i = 0; i < this.timeData.length; i++) {
            const v = this.timeData[i] / 128.0;
            const y = v * this.canvas.height / 2;
            
            if (i === 0) {
                this.ctx.moveTo(x, y);
            } else {
                this.ctx.lineTo(x, y);
            }
            
            x += sliceWidth;
        }
        
        this.ctx.stroke();
        
        // Add glow effect
        this.ctx.shadowColor = color;
        this.ctx.shadowBlur = 20;
        this.ctx.stroke();
        this.ctx.shadowBlur = 0;
    }
    
    drawFrequencyBars(color) {
        if (!this.frequencyData) return;
        
        const barWidth = this.canvas.width / this.frequencyData.length * 2;
        let x = 0;
        
        // Create gradient
        const gradient = this.ctx.createLinearGradient(0, this.canvas.height, 0, 0);
        gradient.addColorStop(0, color);
        gradient.addColorStop(1, this.lightenColor(color, 40));
        
        this.ctx.fillStyle = gradient;
        
        for (let i = 0; i < this.frequencyData.length; i++) {
            const barHeight = (this.frequencyData[i] / 255) * this.canvas.height * (this.settings.sensitivity / 5);
            
            this.ctx.fillRect(x, this.canvas.height - barHeight, barWidth, barHeight);
            
            x += barWidth + 1;
        }
        
        // Add glow effect
        this.ctx.shadowColor = color;
        this.ctx.shadowBlur = 15;
        this.ctx.fillStyle = color;
        
        x = 0;
        for (let i = 0; i < this.frequencyData.length; i++) {
            const barHeight = (this.frequencyData[i] / 255) * this.canvas.height * (this.settings.sensitivity / 5);
            this.ctx.fillRect(x, this.canvas.height - barHeight, barWidth, barHeight);
            x += barWidth + 1;
        }
        this.ctx.shadowBlur = 0;
    }
    
    drawCircularVisualization(color) {
        if (!this.frequencyData) return;
        
        const centerX = this.canvas.width / 2;
        const centerY = this.canvas.height / 2;
        const radius = Math.min(centerX, centerY) * 0.7;
        
        this.ctx.strokeStyle = color;
        this.ctx.lineWidth = 2;
        
        // Draw multiple concentric circles
        for (let ring = 0; ring < 3; ring++) {
            this.ctx.beginPath();
            
            const ringRadius = radius * (0.5 + ring * 0.25);
            const dataStep = Math.floor(this.frequencyData.length / 64); // Use fewer points for smoother circle
            
            for (let i = 0; i < 64; i++) {
                const dataIndex = Math.min(i * dataStep, this.frequencyData.length - 1);
                const amplitude = this.frequencyData[dataIndex] / 255;
                const angle = (i / 64) * Math.PI * 2;
                
                const r = ringRadius + amplitude * 50 * (this.settings.sensitivity / 5);
                const x = centerX + Math.cos(angle) * r;
                const y = centerY + Math.sin(angle) * r;
                
                if (i === 0) {
                    this.ctx.moveTo(x, y);
                } else {
                    this.ctx.lineTo(x, y);
                }
            }
            
            this.ctx.closePath();
            this.ctx.stroke();
        }
        
        // Add glow effect
        this.ctx.shadowColor = color;
        this.ctx.shadowBlur = 20;
        this.ctx.stroke();
        this.ctx.shadowBlur = 0;
    }
    
    drawParticles(color) {
        if (!this.frequencyData) return;
        
        const centerX = this.canvas.width / 2;
        const centerY = this.canvas.height / 2;
        
        // Initialize particles if not exists
        if (!this.particles) {
            this.particles = [];
            for (let i = 0; i < 100; i++) {
                this.particles.push({
                    x: Math.random() * this.canvas.width,
                    y: Math.random() * this.canvas.height,
                    vx: (Math.random() - 0.5) * 2,
                    vy: (Math.random() - 0.5) * 2,
                    size: Math.random() * 3 + 1,
                    life: Math.random()
                });
            }
        }
        
        // Calculate average frequency
        const avgFreq = this.frequencyData.reduce((sum, val) => sum + val, 0) / this.frequencyData.length;
        const intensity = (avgFreq / 255) * (this.settings.sensitivity / 5);
        
        this.ctx.fillStyle = color;
        this.ctx.shadowColor = color;
        this.ctx.shadowBlur = 10;
        
        // Update and draw particles
        this.particles.forEach(particle => {
            // Update position
            particle.x += particle.vx * intensity;
            particle.y += particle.vy * intensity;
            
            // Wrap around screen
            if (particle.x < 0) particle.x = this.canvas.width;
            if (particle.x > this.canvas.width) particle.x = 0;
            if (particle.y < 0) particle.y = this.canvas.height;
            if (particle.y > this.canvas.height) particle.y = 0;
            
            // Draw particle
            this.ctx.globalAlpha = intensity * 0.8;
            this.ctx.beginPath();
            this.ctx.arc(particle.x, particle.y, particle.size * intensity, 0, Math.PI * 2);
            this.ctx.fill();
        });
        
        this.ctx.globalAlpha = 1;
        this.ctx.shadowBlur = 0;
    }
    
    lightenColor(color, percent) {
        // Simple color lightening function
        const num = parseInt(color.replace("#", ""), 16);
        const amt = Math.round(2.55 * percent);
        const R = (num >> 16) + amt;
        const G = (num >> 8 & 0x00FF) + amt;
        const B = (num & 0x0000FF) + amt;
        return "#" + (0x1000000 + (R < 255 ? R < 1 ? 0 : R : 255) * 0x10000 +
            (G < 255 ? G < 1 ? 0 : G : 255) * 0x100 +
            (B < 255 ? B < 1 ? 0 : B : 255)).toString(16).slice(1);
    }
    
    updateThemeColors() {
        // Update colors based on current theme
        const root = document.documentElement;
        this.settings.maleColor = getComputedStyle(root).getPropertyValue('--male-voice-color').trim() || '#007bff';
        this.settings.femaleColor = getComputedStyle(root).getPropertyValue('--female-voice-color').trim() || '#dc3545';
    }
    
    loadModalSettings() {
        // Load current settings into modal inputs
        document.getElementById('maleColor').value = this.settings.maleColor;
        document.getElementById('femaleColor').value = this.settings.femaleColor;
        document.getElementById('animationSpeed').value = this.settings.animationSpeed;
        document.getElementById('smoothAnimation').checked = this.settings.smoothAnimation;
        document.getElementById('fftSize').value = this.settings.fftSize;
        document.getElementById('smoothing').value = this.settings.smoothingTimeConstant;
    }
    
    saveModalSettings() {
        // Save settings from modal
        this.settings.maleColor = document.getElementById('maleColor').value;
        this.settings.femaleColor = document.getElementById('femaleColor').value;
        this.settings.animationSpeed = parseInt(document.getElementById('animationSpeed').value);
        this.settings.smoothAnimation = document.getElementById('smoothAnimation').checked;
        this.settings.fftSize = parseInt(document.getElementById('fftSize').value);
        this.settings.smoothingTimeConstant = parseFloat(document.getElementById('smoothing').value);
        
        // Update CSS custom properties
        document.documentElement.style.setProperty('--male-voice-color', this.settings.maleColor);
        document.documentElement.style.setProperty('--female-voice-color', this.settings.femaleColor);
        
        // Update analyzer if active
        if (this.analyzer) {
            this.analyzer.fftSize = this.settings.fftSize;
            this.analyzer.smoothingTimeConstant = this.settings.smoothingTimeConstant;
            
            // Recreate data arrays if FFT size changed
            if (this.bufferLength !== this.analyzer.frequencyBinCount) {
                this.bufferLength = this.analyzer.frequencyBinCount;
                this.frequencyData = new Uint8Array(this.bufferLength);
                this.timeData = new Uint8Array(this.bufferLength);
            }
        }
        
        this.saveSettings();
        
        // Close modal
        const modal = bootstrap.Modal.getInstance(document.getElementById('settingsModal'));
        modal.hide();
        
        this.showToast('Settings saved successfully', 'success');
    }
    
    saveSettings() {
        localStorage.setItem('audioVisualizerSettings', JSON.stringify(this.settings));
    }
    
    loadSettings() {
        const saved = localStorage.getItem('audioVisualizerSettings');
        if (saved) {
            this.settings = { ...this.settings, ...JSON.parse(saved) };
        }
        
        // Apply loaded settings to UI
        const visualizationType = document.getElementById('visualizationType');
        if (visualizationType) {
            visualizationType.value = this.settings.visualizationType;
        }
        
        const sensitivity = document.getElementById('sensitivity');
        if (sensitivity) {
            sensitivity.value = this.settings.sensitivity;
        }
    }
    
    showToast(message, type = 'info') {
        const toastElement = type === 'error' ? 
            document.getElementById('errorToast') : 
            document.getElementById('successToast');
        
        const messageElement = type === 'error' ? 
            document.getElementById('errorMessage') : 
            document.getElementById('successMessage');
        
        if (toastElement && messageElement) {
            messageElement.textContent = message;
            const toast = new bootstrap.Toast(toastElement);
            toast.show();
        }
    }
    
    destroy() {
        if (this.animationId) {
            cancelAnimationFrame(this.animationId);
        }
        
        if (this.audioElement) {
            this.audioElement.pause();
            this.audioElement = null;
        }
        
        if (this.audioContext) {
            this.audioContext.close();
        }
    }
}

/**
 * Fullscreen Handler
 */
class FullscreenHandler {
    constructor() {
        this.isFullscreen = false;
        this.fullscreenToggle = document.getElementById('fullscreenToggle');
        this.visualizationContainer = document.querySelector('.visualization-container');
        
        this.init();
    }
    
    init() {
        if (this.fullscreenToggle) {
            this.fullscreenToggle.addEventListener('click', () => this.toggleFullscreen());
        }
        
        // Listen for fullscreen changes
        document.addEventListener('fullscreenchange', () => this.handleFullscreenChange());
        document.addEventListener('webkitfullscreenchange', () => this.handleFullscreenChange());
        document.addEventListener('mozfullscreenchange', () => this.handleFullscreenChange());
        document.addEventListener('MSFullscreenChange', () => this.handleFullscreenChange());
        
        // ESC key to exit fullscreen
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.isFullscreen) {
                this.exitFullscreen();
            }
        });
    }
    
    toggleFullscreen() {
        if (this.isFullscreen) {
            this.exitFullscreen();
        } else {
            this.enterFullscreen();
        }
    }
    
    enterFullscreen() {
        if (!this.visualizationContainer) return;
        
        const element = this.visualizationContainer;
        
        if (element.requestFullscreen) {
            element.requestFullscreen();
        } else if (element.webkitRequestFullscreen) {
            element.webkitRequestFullscreen();
        } else if (element.mozRequestFullScreen) {
            element.mozRequestFullScreen();
        } else if (element.msRequestFullscreen) {
            element.msRequestFullscreen();
        }
    }
    
    exitFullscreen() {
        if (document.exitFullscreen) {
            document.exitFullscreen();
        } else if (document.webkitExitFullscreen) {
            document.webkitExitFullscreen();
        } else if (document.mozCancelFullScreen) {
            document.mozCancelFullScreen();
        } else if (document.msExitFullscreen) {
            document.msExitFullscreen();
        }
    }
    
    handleFullscreenChange() {
        this.isFullscreen = !!(document.fullscreenElement || 
                                document.webkitFullscreenElement || 
                                document.mozFullScreenElement || 
                                document.msFullscreenElement);
        
        this.updateFullscreenUI();
        
        // Trigger canvas resize
        if (window.audioVisualizer) {
            setTimeout(() => window.audioVisualizer.resizeCanvas(), 100);
        }
    }
    
    updateFullscreenUI() {
        if (!this.fullscreenToggle) return;
        
        const icon = this.fullscreenToggle.querySelector('i');
        if (icon) {
            if (this.isFullscreen) {
                icon.className = 'fas fa-compress';
                this.fullscreenToggle.title = 'Exit Fullscreen';
            } else {
                icon.className = 'fas fa-expand';
                this.fullscreenToggle.title = 'Enter Fullscreen';
            }
        }
    }
}

/**
 * Background Manager
 */
class BackgroundManager {
    constructor() {
        this.backgroundImage = null;
        this.backgroundUpload = document.getElementById('backgroundUpload');
        this.clearBackground = document.getElementById('clearBackground');
        
        this.init();
    }
    
    init() {
        if (this.backgroundUpload) {
            this.backgroundUpload.addEventListener('change', (e) => this.handleBackgroundUpload(e));
        }
        
        if (this.clearBackground) {
            this.clearBackground.addEventListener('click', () => this.clearBackgroundImage());
        }
    }
    
    async handleBackgroundUpload(event) {
        const file = event.target.files[0];
        if (!file) return;
        
        try {
            const formData = new FormData();
            formData.append('background', file);
            
            const response = await fetch('/upload-background', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.setBackgroundImage(result.image_url);
                this.showToast(result.message, 'success');
            } else {
                this.showToast(result.error, 'error');
            }
        } catch (error) {
            console.error('Error uploading background:', error);
            this.showToast('Failed to upload background image', 'error');
        }
    }
    
    setBackgroundImage(imageUrl) {
        const img = new Image();
        img.onload = () => {
            this.backgroundImage = img;
            document.body.style.setProperty('--background-image', `url(${imageUrl})`);
            document.body.style.setProperty('--background-opacity', '0.3');
        };
        img.src = imageUrl;
    }
    
    clearBackgroundImage() {
        this.backgroundImage = null;
        document.body.style.removeProperty('--background-image');
        document.body.style.removeProperty('--background-opacity');
        
        if (this.backgroundUpload) {
            this.backgroundUpload.value = '';
        }
        
        this.showToast('Background image cleared', 'success');
    }
    
    drawBackground(ctx, width, height) {
        if (!this.backgroundImage) return;
        
        // Draw background image with proper scaling
        const imgAspect = this.backgroundImage.width / this.backgroundImage.height;
        const canvasAspect = width / height;
        
        let drawWidth, drawHeight, offsetX = 0, offsetY = 0;
        
        if (imgAspect > canvasAspect) {
            drawHeight = height;
            drawWidth = height * imgAspect;
            offsetX = (width - drawWidth) / 2;
        } else {
            drawWidth = width;
            drawHeight = width / imgAspect;
            offsetY = (height - drawHeight) / 2;
        }
        
        ctx.globalAlpha = 0.3;
        ctx.drawImage(this.backgroundImage, offsetX, offsetY, drawWidth, drawHeight);
        ctx.globalAlpha = 1.0;
    }
    
    showToast(message, type = 'info') {
        const toastElement = type === 'error' ? 
            document.getElementById('errorToast') : 
            document.getElementById('successToast');
        
        const messageElement = type === 'error' ? 
            document.getElementById('errorMessage') : 
            document.getElementById('successMessage');
        
        if (toastElement && messageElement) {
            messageElement.textContent = message;
            const toast = new bootstrap.Toast(toastElement);
            toast.show();
        }
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.audioVisualizer = new AudioVisualizer();
    
    // Cleanup on page unload
    window.addEventListener('beforeunload', () => {
        if (window.audioVisualizer) {
            window.audioVisualizer.destroy();
        }
    });
});