/**
 * Gender Detection Module - Analyzes audio frequency for basic gender classification
 */
class GenderDetector {
    constructor() {
        this.analysisHistory = [];
        this.historySize = 30; // Number of frames to keep in history
        this.maleFreqRange = { min: 85, max: 180 }; // Hz - typical male fundamental frequency
        this.femaleFreqRange = { min: 165, max: 265 }; // Hz - typical female fundamental frequency
        this.confidenceThreshold = 0.6; // Minimum confidence for classification
        
        this.currentGender = null;
        this.confidence = 0;
        
        // UI elements
        this.genderText = document.getElementById('genderText');
        this.genderColor = document.getElementById('genderColor');
        
        this.init();
    }
    
    init() {
        // Initialize UI
        this.updateGenderDisplay('none', 0);
    }
    
    /**
     * Analyze audio data to detect gender
     * @param {Uint8Array} frequencyData - Audio frequency data from analyzer
     * @param {number} sampleRate - Audio sample rate
     * @param {number} fftSize - FFT size for frequency analysis
     */
    analyzeGender(frequencyData, sampleRate, fftSize) {
        try {
            // Calculate fundamental frequency
            const fundamentalFreq = this.findFundamentalFrequency(frequencyData, sampleRate, fftSize);
            
            if (fundamentalFreq === null || fundamentalFreq < 50 || fundamentalFreq > 400) {
                // No valid frequency detected or outside human voice range
                this.addToHistory(null);
                this.updateCurrentGender();
                return;
            }
            
            // Classify gender based on fundamental frequency
            let genderClassification = null;
            let confidence = 0;
            
            if (fundamentalFreq >= this.maleFreqRange.min && fundamentalFreq <= this.maleFreqRange.max) {
                genderClassification = 'male';
                // Calculate confidence based on how well it fits in the range
                const center = (this.maleFreqRange.min + this.maleFreqRange.max) / 2;
                const range = this.maleFreqRange.max - this.maleFreqRange.min;
                confidence = Math.max(0, 1 - Math.abs(fundamentalFreq - center) / (range / 2));
            } else if (fundamentalFreq >= this.femaleFreqRange.min && fundamentalFreq <= this.femaleFreqRange.max) {
                genderClassification = 'female';
                // Calculate confidence based on how well it fits in the range
                const center = (this.femaleFreqRange.min + this.femaleFreqRange.max) / 2;
                const range = this.femaleFreqRange.max - this.femaleFreqRange.min;
                confidence = Math.max(0, 1 - Math.abs(fundamentalFreq - center) / (range / 2));
            } else {
                // Frequency outside typical ranges - try to make a best guess
                if (fundamentalFreq < this.maleFreqRange.min) {
                    genderClassification = 'male';
                    confidence = 0.3; // Low confidence
                } else if (fundamentalFreq > this.femaleFreqRange.max) {
                    genderClassification = 'female';
                    confidence = 0.3; // Low confidence
                } else {
                    // In the overlap zone - use additional heuristics
                    const spectralCentroid = this.calculateSpectralCentroid(frequencyData, sampleRate, fftSize);
                    if (spectralCentroid > 2000) {
                        genderClassification = 'female';
                        confidence = 0.4;
                    } else {
                        genderClassification = 'male';
                        confidence = 0.4;
                    }
                }
            }
            
            // Add to history and update current classification
            this.addToHistory({ gender: genderClassification, confidence, frequency: fundamentalFreq });
            this.updateCurrentGender();
            
        } catch (error) {
            console.error('Error in gender analysis:', error);
            this.addToHistory(null);
            this.updateCurrentGender();
        }
    }
    
    /**
     * Find the fundamental frequency using autocorrelation
     */
    findFundamentalFrequency(frequencyData, sampleRate, fftSize) {
        try {
            // Convert frequency data to amplitude values
            const amplitudes = new Float32Array(frequencyData.length);
            for (let i = 0; i < frequencyData.length; i++) {
                amplitudes[i] = frequencyData[i] / 255.0;
            }
            
            // Find peak in the frequency domain (simplified approach)
            let maxAmplitude = 0;
            let peakIndex = 0;
            
            // Focus on human voice frequency range (80-400 Hz)
            const minIndex = Math.floor(80 * fftSize / sampleRate);
            const maxIndex = Math.floor(400 * fftSize / sampleRate);
            
            for (let i = minIndex; i < maxIndex && i < amplitudes.length; i++) {
                if (amplitudes[i] > maxAmplitude) {
                    maxAmplitude = amplitudes[i];
                    peakIndex = i;
                }
            }
            
            // Ensure we have a significant peak
            if (maxAmplitude < 0.1) {
                return null; // No significant signal
            }
            
            // Convert index to frequency
            const frequency = peakIndex * sampleRate / fftSize;
            return frequency;
            
        } catch (error) {
            console.error('Error finding fundamental frequency:', error);
            return null;
        }
    }
    
    /**
     * Calculate spectral centroid as additional feature
     */
    calculateSpectralCentroid(frequencyData, sampleRate, fftSize) {
        try {
            let weightedSum = 0;
            let magnitudeSum = 0;
            
            for (let i = 0; i < frequencyData.length; i++) {
                const magnitude = frequencyData[i] / 255.0;
                const frequency = i * sampleRate / fftSize;
                
                weightedSum += frequency * magnitude;
                magnitudeSum += magnitude;
            }
            
            return magnitudeSum > 0 ? weightedSum / magnitudeSum : 0;
        } catch (error) {
            console.error('Error calculating spectral centroid:', error);
            return 0;
        }
    }
    
    /**
     * Add analysis result to history
     */
    addToHistory(result) {
        this.analysisHistory.push(result);
        
        // Keep only recent history
        if (this.analysisHistory.length > this.historySize) {
            this.analysisHistory.shift();
        }
    }
    
    /**
     * Update current gender classification based on history
     */
    updateCurrentGender() {
        try {
            // Filter out null results
            const validResults = this.analysisHistory.filter(result => result !== null);
            
            if (validResults.length === 0) {
                this.currentGender = null;
                this.confidence = 0;
                this.updateGenderDisplay('none', 0);
                return;
            }
            
            // Count occurrences of each gender
            const genderCounts = { male: 0, female: 0 };
            const confidenceSum = { male: 0, female: 0 };
            
            validResults.forEach(result => {
                if (result.confidence >= this.confidenceThreshold) {
                    genderCounts[result.gender]++;
                    confidenceSum[result.gender] += result.confidence;
                }
            });
            
            // Determine most likely gender
            let predictedGender = null;
            let avgConfidence = 0;
            
            if (genderCounts.male > genderCounts.female) {
                predictedGender = 'male';
                avgConfidence = genderCounts.male > 0 ? confidenceSum.male / genderCounts.male : 0;
            } else if (genderCounts.female > genderCounts.male) {
                predictedGender = 'female';
                avgConfidence = genderCounts.female > 0 ? confidenceSum.female / genderCounts.female : 0;
            }
            
            // Update if classification changed or confidence is high enough
            if (predictedGender !== this.currentGender || avgConfidence > this.confidence) {
                this.currentGender = predictedGender;
                this.confidence = avgConfidence;
                this.updateGenderDisplay(predictedGender, avgConfidence);
            }
            
        } catch (error) {
            console.error('Error updating gender classification:', error);
            this.updateGenderDisplay('none', 0);
        }
    }
    
    /**
     * Update the UI display
     */
    updateGenderDisplay(gender, confidence) {
        try {
            if (!this.genderText || !this.genderColor) return;
            
            if (gender === 'male') {
                this.genderText.textContent = `Male Voice (${Math.round(confidence * 100)}%)`;
                this.genderColor.className = 'gender-color male';
            } else if (gender === 'female') {
                this.genderText.textContent = `Female Voice (${Math.round(confidence * 100)}%)`;
                this.genderColor.className = 'gender-color female';
            } else {
                this.genderText.textContent = 'No Voice Detected';
                this.genderColor.className = 'gender-color';
            }
        } catch (error) {
            console.error('Error updating gender display:', error);
        }
    }
    
    /**
     * Get current gender classification
     */
    getCurrentGender() {
        return {
            gender: this.currentGender,
            confidence: this.confidence
        };
    }
    
    /**
     * Reset detection state
     */
    reset() {
        this.analysisHistory = [];
        this.currentGender = null;
        this.confidence = 0;
        this.updateGenderDisplay('none', 0);
    }
    
    /**
     * Get gender color for visualization
     */
    getGenderColor() {
        if (this.currentGender === 'male') {
            return getComputedStyle(document.documentElement).getPropertyValue('--male-voice-color').trim() || '#007bff';
        } else if (this.currentGender === 'female') {
            return getComputedStyle(document.documentElement).getPropertyValue('--female-voice-color').trim() || '#dc3545';
        }
        return '#6c757d'; // Default gray
    }
}

// Make GenderDetector available globally
window.GenderDetector = GenderDetector;
